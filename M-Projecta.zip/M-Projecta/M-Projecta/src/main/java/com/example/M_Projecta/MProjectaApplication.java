package com.example.M_Projecta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MProjectaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MProjectaApplication.class, args);
	}

}
