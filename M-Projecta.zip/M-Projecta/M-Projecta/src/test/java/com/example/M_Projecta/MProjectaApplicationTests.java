package com.example.M_Projecta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MProjectaApplicationTests {

	@Test
	void contextLoads() {
	}

}
